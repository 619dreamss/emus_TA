@extends('main_layout')
@section('content')

<div class="main-content">
    <div class="container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-12">
                    <div class="page-header-title">
                        <i class="ik ik-file-text bg-blue"></i>
                        <div class="d-inline">
                            <h5>Keluhan</h5>
                            <span>Keluhan Detail.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3 class="d-block w-100">{{ ucwords($complaint->complaint_category) }}</h3></div>
            <div class="card-body" id="printArea">
                <div class="row invoice-info">
                    <div class="col-sm-12 invoice-col">
                        <b>No. Keluhan #{{ $complaint->complaint_number }}</b>
                        <div class="float-right">Tanggal Keluhan: {{ date('Y/m/d', strtotime($complaint->created_at)) }}</div>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nama Tenant</th>
                                    <th>Email</th>
                                    <th>No. Telp</th>
                                    <th>Type ID.</th>
                                    <th>Identitias</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr></tr>
                                    <td>{{ $complaint->tenant->tenant_name }} Hari</td>
                                    <td>{{ $complaint->tenant->tenant_email}}</td>
                                    <td>{{ $complaint->tenant->tenant_phone }}</td>
                                    <td>{{ $complaint->tenant->tenant_id_type }}</td>
                                    <td>{{ $complaint->tenant->tenant_id_number }}</td>
                                    <td>{{ $complaint->tenant->tenant_address }}</td>
                                </tr>
                            </tbody>
                        </table>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Waktu Pengerjaan</th>
                                    <th>Prioritas</th>
                                    <th>Status</th>
                                    <th>Unit</th>
                                    <th>Pengelola</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>{{ $complaint->complaint_duration }} Hari</td>
                                    <td>{{ $complaint->complaint_priority}}</td>
                                    <td>{{ $complaint->status->status_name }}</td>
                                    <td>{{ $complaint->unit->unit_number }}</td>
                                    <td>{{ $complaint->unit->unit_name }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <h5 class="lead">Keterangan:</h5>
                        <div class="alert alert-primary mt-20">
                            <p>
                                {!! $complaint->complaint_remark !!}
                            </p>
                        </div>
                    </div>
                    {{-- <div class="col-6">
                        <p class="lead">Tenggat Waktu : <span class="badge badge-pill badge-danger">{{ date('Y/m/d', strtotime($invoice->invoice_payment_timelimit)) }}</span></p>
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <th style="width:50%">Biaya Pemakaian Bulan {{ $invoice->invoice_month }}:</th>
                                    <td>{{ number_format($invoice->invoice_amount) }}</td>
                                </tr>
                                <tr>
                                    <th style="width:50%">Biaya PPN (10%):</th>
                                    <td>{{ number_format($invoice->invoice_ppn) }}</td>
                                </tr>
                                <tr>
                                    <th>Total:</th>
                                    <td>{{ number_format($invoice->invoice_amount + $invoice->invoice_ppn) }}</td>
                                </tr>
                            </table>
                        </div>
                    </div> --}}
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ url('tenant-complaint') }}" class="btn btn-md btn-warning"><i class="ik ik-arrow-left"></i>Kembali</a>
                        <button class="btn btn-md btn-success" onclick="printArea();"><i class="fa fa-print"></i> Print</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
    <script>
        function printArea()
        {
            var options = {  };
            $("#printArea").printArea( options );
        }
    </script>
@endsection