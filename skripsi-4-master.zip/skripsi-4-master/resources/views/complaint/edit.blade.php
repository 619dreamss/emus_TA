@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>From Komplain.</h3></div>
            <div class="card-body">
                {!! Form::model($complaint, ['route' => ['tenant-complaint.update', $complaint->complaint_id], 'method' => 'put']) !!}
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="complaint_category">Jenis Komplain</label>
                                <select name="complaint_category" id="complaint_category" class="form-control">
                                    <option value="">Pilih Jenis Komplain</option>
                                    @foreach($category as $item)
                                        <option value="{{ $item['name'] }}" {{ ($item['name'] == $complaint['complaint_category'])?'selected':'' }}>{{ $item['name'] }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('complaint_category'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('complaint_category') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @if(strtolower($user['role']['role_name']) == "tenant")
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="unit_id">Unit</label>
                                <select name="unit_id" id="unit_id" class="form-control">
                                    <option value="">Pilih Unit</option>
                                    @foreach($units as $unit)
                                        <option value="{{ $unit->unit_id }}" {{ ($unit->unit_id == $complaint->unit_id)?'selected':'' }}>{{ $unit->unit_number.' - '.$unit->unit_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('unit_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                        @if(strtolower($user['role']['role_name']) != 'tenant')
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="status_id"><span class="badge badge-pill badge-danger">Status</span></label>
                                <select name="status_id" id="status_id" class="form-control">
                                    <option value="">Pilih Status</option>
                                    @foreach($status as $val)
                                        <option value="{{ $val->status_id }}" {{ ($val->status_id  == $complaint->status_id)?'selected':'' }}>{{ $val->status_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('status_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('status_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="complaint_priority"><span class="badge badge-pill badge-danger">Prioritas</span></label>
                                <select name="complaint_priority" id="complaint_priority" class="form-control">
                                    <option value="low" {{(strtolower($complaint->complaint_priority)=='low')?'selected':''}}>Low</option>
                                    <option value="hight" {{(strtolower($complaint->complaint_priority)=='high')?'selected':''}}>High</option>
                                </select>
                                @if ($errors->has('complaint_priority'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('complaint_priority') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="complaint_remark">Keterangan / Catatan Khusus</label>
                                <textarea type="date" name="complaint_remark" class="form-control" placeholder="Masukkan informasi tambahan disini." value="{{$complaint->complaint_remark }}">{{ $complaint->complaint_remark }}</textarea>
                                @if ($errors->has('complaint_remark'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('complaint_remark') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant-complaint') }}" class="btn btn-warning"><i class="ik ik-arrow-left"></i> Kembali</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection