@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-12">
                    <div class="page-header-title">
                        <i class="ik ik-file-text bg-blue"></i>
                        <div class="d-inline">
                            <h5>Komplain Tenant</h5>
                            <span>History Komplain Tenant.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            @if(FunctionsHelper::checkRole($menuId, 'create') && strtolower($user['role']['role_name']) == 'tenant')
            <div class="card-header row">
                <div class="col col-sm-12">
                    <a href="{{ url('tenant-complaint/create') }}" class="badge badge-pill badge-success"><i class="ik ik-plus"></i> Tambah Data</a>
                </div>
            </div>
            @endif
            <div class="card-body">
                <table class="table table-export">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>No. Komplain</th>
                            <th>Pemilik/Tenant</th>
                            <th>Unit</th>
                            <th>Jenis Komplain</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Prioritas</th>
                            <th>Catatan</th>
                            <th>Aksi</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($complaints as $key => $item)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            <td>{{ $item->complaint_number }}</td>
                            <td>{{ ucwords($item->tenant->tenant_name) }}</td>
                            <td>{{ ucwords($item->unit->unit_number.' - '.$item->unit->unit_name) }}</td>
                            <td><span class="badge badge-pill badge-primary mb-1">{{ ucwords($item->complaint_category) }}</span></td>
                            <td>{{ date('Y/m/d', strtotime($item->created_at)) }}</td>
                            <td><span class="badge badge-pill {{ (strtoupper($item->status->status_name) == 'COMPLETE')?'badge-success':'badge-danger' }} mb-1">{{ $item->status->status_name }}</span></td>
                            <td><span class="badge badge-pill {{ (strtoupper($item->complaint_priority) == 'LOW')?'badge-success':'badge-danger' }} mb-1">{{ $item->complaint_priority }}</span></td>
                            <td>{{ $item->complaint_remark }}</td>
                            <td width="80px">
                                <a href="{{ URL::to('tenant-complaint/detail/'.$item->complaint_id) }}" data-toggle="tooltip" data-placement="left" title="Detail" class="btn btn-icon btn-primary"><i class="ik ik-eye"></i></a>
                                @if(FunctionsHelper::checkRole($menuId, 'edit'))
                                <a href="{{ URL::to('tenant-complaint/edit/'.$item->complaint_id) }}" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-icon btn-warning"><i class="ik ik-edit"></i></a>
                                @endif
                            </td>
                            <td></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    let excelButtonTrans = 'Download Excel'
    $('.table-export').dataTable({
        dom: 'lBfrtip',
        searchable: true,
        buttons: [
            {
                extend: 'excel',
                className: 'btn btn-success',
                text: excelButtonTrans,
                exportOptions: {
                    columns: [0,1,2,3,4,5,6,7,8]
                }
            }
        ]
    });
</script>
@endsection