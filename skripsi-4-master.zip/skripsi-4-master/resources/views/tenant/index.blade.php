@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            @if(FunctionsHelper::checkAction($menuId, 'create'))
            <div class="card-header row">
                <div class="col col-sm-12">
                    <a data-toggle="tooltip" data-placement="left" title="Tambah" href="{{ url('tenant/add') }}" class="badge badge-pill badge-primary">Tambah Tenant</a>
                </div>
            </div>
            @endif
            <div class="card-body table-responsive">
                <table class="table table-export" style="overflow-x: auto">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>No. Telp</th>
                            <th>No. Identitas</th>
                            <th>Unit</th>
                            <th>Action</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($tenants as $key => $item)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            <td>{{ ucwords($item->tenant_name) }}</td>
                            <td>{{ $item->tenant_email }}</td>
                            <td>{{ $item->tenant_phone }}</td>
                            <td>{{ strtoupper($item->tenant_id_type).' / '.$item->tenant_id_number }}</td>
                            <td>
                                @foreach($item->units as $unit)
                                    <a href="{{ url('tenant-unit?tenant_id='.$item->tenant_id) }}">{{ $unit->unit_number }}</a></br>
                                @endforeach
                            </td>
                            <td width="100px">
                                @if(strtoupper($user['role']['role_name']) == "FINANCE")
                                    <a href="{{ URL::to('tenant/invoice/'.$item->tenant_id) }}" data-toggle="tooltip" data-placement="left" title="Buat Invoice" class="btn btn-icon btn-primary"><i class="ik ik-dollar-sign"></i></a>
                                @endif
                                @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                    <a href="{{ URL::to('tenant/edit/'.$item->tenant_id) }}" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-icon btn-warning"><i class="ik ik-edit"></i></a>
                                @endif
                                @if(FunctionsHelper::checkAction($menuId, 'create'))
                                    <a href="{{ URL::to('tenant/add/unit/'.$item->tenant_id) }}" data-toggle="tooltip" data-placement="left" title="Tambah Unit" class="btn btn-icon btn-success"><i class="ik ik-home"></i></a>
                                @endif
                                @if(FunctionsHelper::checkAction($menuId, 'delete'))
                                    <button data-href="{{ URL::to('tenant/delete/'.$item->tenant_id) }}" data-placement="right" data-toggle="modal" data-target="#confirmationDelete" title="Delete" class="btn btn-icon btn-danger" onclick="confirmationDelete(this)"><i class="ik ik-trash"></i></button>
                                @endif
                                
                            </td>
                            <td>&nbsp;</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>

<script>
    let excelButtonTrans = 'Download Excel'
    $('.table-export').dataTable({
        dom: 'lBfrtip',
        searchable: true,
        buttons: [
            {
                extend: 'excel',
                className: 'btn btn-success',
                text: excelButtonTrans,
                exportOptions: {
                    columns: [0,1,2,3,4,5]
                }
            }
        ]
    });
</script>
@endsection
