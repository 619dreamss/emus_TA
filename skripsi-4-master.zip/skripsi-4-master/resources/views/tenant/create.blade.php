@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>Form penambahan tenant.</h3></div>
            <div class="card-body">
                {!! Form::open(['route' => 'tenant.store', 'method' => 'post']) !!}
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="name">Nama Lengkap</label>
                                <input type="text" id="name" name="name" class="form-control" placeholder="Nama lengkap" value="{{ old('name') }}">
                                @if ($errors->has('name'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="tenant_email">tenant_email</label>
                                <input type="text" name="tenant_email" class="form-control" placeholder="Alamat Email" value="{{ old('tenant_email') }}">
                                @if ($errors->has('tenant_email'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('tenant_email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="password">Password</label>
                                <input type="text" name="password" class="form-control" placeholder="Kata sandi/Password" value="{{ old('password') }}">
                                @if ($errors->has('password'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="tenant_phone">No. Telp</label>
                                <input type="text" name="tenant_phone" class="form-control" placeholder="No. Hp / Rumah" value="{{ old('tenant_phone') }}">
                                @if ($errors->has('tenant_phone'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('tenant_phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <label for="tenant_id_type">Jenis Identitas</label>
                            <select class="form-control" name="tenant_id_type">
                                <option value="">Pilih Jenis ID</option>
                                <option value="KTP">KTP</option>
                                <option value="SIM">SIM</option>
                            </select>
                            @if ($errors->has('tenant_id_type'))
                                <span class="help-block error">
                                    <strong>{{ $errors->first('tenant_id_type') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="tenant_id_number">No. Identitas</label>
                                <input type="text" name="tenant_id_number" class="form-control" placeholder="No. KTP / No. SIM" value="{{ old('tenant_id_number') }}">
                                @if ($errors->has('tenant_id_number'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('tenant_id_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <label for="unit_id">Unit</label>
                            <select class="form-control" name="unit_id">
                                <option value="">Pilih Unit</option>
                                @foreach($units as $unit)
                                    <option value="{{ $unit->unit_id }}">{{ $unit->unit_number.' - '.$unit->unit_name }}</option>
                                @endforeach
                            </select>
                            @if ($errors->has('unit_id'))
                                <span class="help-block error">
                                    <strong>{{ $errors->first('unit_id') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="tenant_address">Alamat</label>
                                <textarea type="text" name="tenant_address" class="form-control" placeholder="Alamat sesuai identitas" value="">{{ old('tenant_address') }}</textarea>
                                @if ($errors->has('tenant_address'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('tenant_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant') }}" class="btn btn-danger"><i class="ik ik-arrow-left"></i> Batal</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection