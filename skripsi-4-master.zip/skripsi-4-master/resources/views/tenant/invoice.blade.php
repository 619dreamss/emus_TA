@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>Form Invoice.</h3></div>
            <div class="card-body">
                {!! Form::open(['route' => 'tenant-invoice.store', 'method' => 'post']) !!}
                <input type="hidden" id="tenant_id" name="tenant_id" class="form-control" placeholder="" value="{{ $id }}">
                    <div class="row">
                        {{-- <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="invoice_number">No. Invoice</label>
                                
                                <input type="text" id="invoice_number" name="invoice_number" class="form-control" placeholder="" value="{{ old('invoice_number') }}">
                                @if ($errors->has('invoice_number'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> --}}
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="invoice_category">Jenis Tagihan</label>
                                <select name="invoice_category" id="invoice_category" class="form-control">
                                    <option value="">Pilih Jenis Tagihan</option>
                                    <option value="Listrik">Listrik</option>
                                    <option value="Air">Air</option>
                                    <option value="Service Charge">Service Charge</option>
                                </select>
                                @if ($errors->has('invoice_category'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_category') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="unit_id">Unit</label>
                                <select name="unit_id" id="invoice_category" class="form-control">
                                    <option value="">Pilih Unit</option>
                                    @foreach($units as $unit)
                                        <option value="{{ $unit->unit_id }}">{{ $unit->unit_number.' - '.$unit->unit_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('unit_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="invoice_amount">Jumlah Tagihan</label>
                                <input type="text" name="invoice_amount" class="form-control" placeholder="" value="{{ old('invoice_amount') }}">
                                @if ($errors->has('invoice_amount'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_amount') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <label for="invoice_month">Bulan Tagihan</label>
                            <select class="form-control" name="invoice_month">
                                <option value="">Silahkan pilih bulan</option>
                                <option value="{{ 'Januari, '.date('Y') }}">{{ 'Januari, '.date('Y') }}</option>
                                <option value="{{ 'Februari, '.date('Y') }}">{{ 'Februari, '.date('Y') }}</option>
                                <option value="{{ 'Maret, '.date('Y') }}">{{ 'Maret, '.date('Y') }}</option>
                                <option value="{{ 'April, '.date('Y') }}">{{ 'April, '.date('Y') }}</option>
                                <option value="{{ 'Mei, '.date('Y') }}">{{ 'Mei, '.date('Y') }}</option>
                                <option value="{{ 'Juni, '.date('Y') }}">{{ 'Juni, '.date('Y') }}</option>
                                <option value="{{ 'Juli, '.date('Y') }}">{{ 'Juli, '.date('Y') }}</option>
                                <option value="{{ 'Agustus, '.date('Y') }}">{{ 'Agustus, '.date('Y') }}</option>
                                <option value="{{ 'September, '.date('Y') }}">{{ 'September, '.date('Y') }}</option>
                                <option value="{{ 'Oktober, '.date('Y') }}">{{ 'Oktober, '.date('Y') }}</option>
                                <option value="{{ 'November, '.date('Y') }}">{{ 'November, '.date('Y') }}</option>
                                <option value="{{ 'Desember, '.date('Y') }}">{{ 'Desember, '.date('Y') }}</option>
                                @if ($errors->has('invoice_month'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_month') }}</strong>
                                    </span>
                                @endif
                            </select>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="invoice_payment_timelimit">Tenggat Waktu</label>
                                <input type="date" name="invoice_payment_timelimit" class="form-control" placeholder="" value="{{ old('invoice_payment_timelimit') }}">
                                @if ($errors->has('invoice_payment_timelimit'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_payment_timelimit') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="invoice_remark">Keterangan / Catatan Khusus</label>
                                <textarea type="date" name="invoice_remark" class="form-control" placeholder="Masukkan informasi tambahan disini." value="{{ old('invoice_remark') }}">{{ old('invoice_remark') }}</textarea>
                                @if ($errors->has('invoice_remark'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_remark') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant') }}" class="btn btn-warning"><i class="ik ik-arrow-left"></i> Kembali</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection