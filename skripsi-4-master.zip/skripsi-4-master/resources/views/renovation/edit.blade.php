@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>From Pengajuan Renovasi.</h3></div>
            <div class="card-body">
                {!! Form::model($renovation, ['route' => ['tenant-renovation.update', $renovation->renovation_id], 'method' => 'put']) !!}
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_desc"><strong>1. Data Tenant</strong></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        @if(strtolower($user['role']['role_name']) == 'tenant')
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label for="unit_id">Unit</label>
                                <select name="unit_id" id="unit_id" class="form-control">
                                    <option value="">Pilih Unit</option>
                                    @foreach($units as $unit)
                                        <option value="{{ $unit->unit_id }}" {{ ($unit->unit_id == $renovation->unit_id)?'selected':'' }}>{{ $unit->unit_number.' - '.$unit->unit_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('unit_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                        @if(strtolower($user['role']['role_name']) != 'tenant')
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label for="status_id"><span class="badge badge-pill badge-danger">Status</span></label>
                                <select name="status_id" id="status_id" class="form-control">
                                    <option value="">Pilih Unit</option>
                                    @foreach($status as $item)
                                        <option value="{{ $item->status_id }}" {{ ($item->status_id == $renovation->status_id)?'selected':'' }}>{{ $item->status_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('unit_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_desc">Keterangan / Catatan Khusus</label>
                                <textarea type="date" name="renovation_desc" class="form-control" placeholder="Masukkan informasi tambahan disini.">{{ $renovation->renovation_desc }}</textarea>
                                @if ($errors->has('renovation_desc'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_desc') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <hr>
                                <label for="renovation_desc"><strong>2. Kontraktor Yang Ditunjuk</strong></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_company_name">Nama Kontraktor/Perusahaan</label>
                                <input type="text" name="renovation_company_name" class="form-control" placeholder="" value="{{ $renovation->renovation_company_name }}">
                                @if ($errors->has('renovation_company_name'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_company_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_contractor_leader">Nama Penanggung Jawab</label>
                                <input type="text" name="renovation_contractor_leader" class="form-control" placeholder="" value="{{ $renovation->renovation_contractor_leader }}">
                                @if ($errors->has('renovation_contractor_leader'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_contractor_leader') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_contractor_phone">No. Telepon Penanggung Jawab</label>
                                <input type="text" name="renovation_contractor_phone" class="form-control" placeholder="" value="{{ $renovation->renovation_contractor_phone }}">
                                @if ($errors->has('renovation_contractor_phone'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_contractor_phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_contractor_id">No. KTP/SIM</label>
                                <input type="text" name="renovation_contractor_id" class="form-control" placeholder="" value="{{ $renovation->renovation_contractor_id }}">
                                @if ($errors->has('renovation_contractor_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_contractor_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_contractor_address">Alamat Kontraktor/Perusahaan</label>
                                <textarea name="renovation_contractor_address" class="form-control" placeholder="" value="{{ old('renovation_contractor_address') }}">{{ $renovation->renovation_contractor_address }}</textarea>
                                @if ($errors->has('renovation_contractor_address'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_contractor_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="renovation_start_date">Tanggal Mulai</label>
                                <input type="date" class="form-control" name="renovation_start_date" value="{{ $renovation->renovation_start_date }}"> 
                                @if ($errors->has('renovation_start_date'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_start_date') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="renovation_end_date">Tanggal Selesai</label>
                                <input type="date" class="form-control" name="renovation_end_date" value="{{ $renovation->renovation_end_date }}">
                                @if ($errors->has('renovation_end_date'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_end_date') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="renovation_start_time">Jam Mulai (Dalam 24)</label>
                                <input type="time" class="form-control" name="renovation_start_time"  value="{{ $renovation->renovation_start_time }}">
                                @if ($errors->has('renovation_start_time'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_start_time') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="renovation_end_time">Jam Selesai (Dalam 24)</label>
                                <input type="time" class="form-control" name="renovation_end_time"  value="{{ $renovation->renovation_end_time }}">
                                @if ($errors->has('renovation_end_time'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_end_time') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_duration">Jumlah Hari</label>
                                <input type="text" name="renovation_duration" class="form-control" placeholder="" value="{{ $renovation->renovation_duration }}">
                                @if ($errors->has('renovation_duration'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_duration') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_worker">Jumlah Pekerja</label>
                                <input type="text" name="renovation_worker" class="form-control" placeholder="" value="{{$renovation->renovation_worker }}">
                                @if ($errors->has('renovation_worker'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_worker') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <hr>
                                <label for="renovation_desc"><strong>3. Data Pekerja</strong></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_worker_name">Nama-nama Pekerja</label>
                                <textarea name="renovation_worker_name" class="form-control" placeholder="Masukkan semua nama pekerja sesuai dengan jumlah pekerja dipisahkan dengan koma(,)" value="{{ old('renovation_worker_name') }}">{{ $renovation->renovation_worker_name }}</textarea>
                                @if ($errors->has('renovation_worker_name'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_worker_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    @if ($user['role']['role_name'])
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_remark">Catatan Renovasi</label>
                                <textarea name="renovation_remark" class="form-control" placeholder="" value="{{ old('renovation_remark') }}">{{ $renovation->renovation_remark }}</textarea>
                                @if ($errors->has('renovation_remark'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('renovation_remark') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endif
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant-renovation') }}" class="btn btn-warning"><i class="ik ik-arrow-left"></i> Kembali</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection