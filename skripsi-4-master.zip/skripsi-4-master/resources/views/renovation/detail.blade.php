@extends('main_layout')
@section('content')

<div class="main-content">
    <div class="container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-12">
                    <div class="page-header-title">
                        <i class="ik ik-file-text bg-blue"></i>
                        <div class="d-inline">
                            <h5>Pengajuan Renovasi</h5>
                            <span>Detail Pengajuan Renovasi.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3 class="d-block w-100">{{ ucwords($renovation->renovation_category) }}</h3></div>
            <div class="card-body" id="printArea">
                <div class="row invoice-info">
                    <div class="col-sm-12 invoice-col">
                        <b>No. Izin Renovasi #{{ $renovation->renovation_approval_number }}</b>
                        <div class="float-right">Tanggal Pengajuan: {{ date('Y/m/d', strtotime($renovation->created_at)) }}</div>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nama Tenant</th>
                                    <th>Email</th>
                                    <th>No. Telp</th>
                                    <th>Type ID.</th>
                                    <th>No. Identitias</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr></tr>
                                    <td>{{ ucwords($renovation->tenant->tenant_name) }}</td>
                                    <td>{{ $renovation->tenant->tenant_email}}</td>
                                    <td>{{ $renovation->tenant->tenant_phone }}</td>
                                    <td>{{ $renovation->tenant->tenant_id_type }}</td>
                                    <td>{{ $renovation->tenant->tenant_id_number }}</td>
                                    <td>{{ $renovation->tenant->tenant_address }}</td>
                                </tr>
                            </tbody>
                        </table>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Kontraktor/Perusahaan</th>
                                    <th>Penanggung Jawab</th>
                                    <th>No.Telp</th>
                                    <th>No. Identitias</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{{ $renovation->renovation_company_name }} Hari</td>
                                    <td>{{ $renovation->renovation_contractor_leader}}</td>
                                    <td>{{ $renovation->renovation_contractor_phone}}</td>
                                    <td>{{ $renovation->renovation_contractor_id}}</td>
                                    <td>{{ $renovation->renovation_contractor_address}}</td>
                                </tr>
                            </tbody>
                        </table>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Tgl Mulai</th>
                                    <th>Tgl Selesai</th>
                                    <th>Jam Mulai</th>
                                    <th>Jam Selesai</th>
                                    <th>Lama Pengerjaan</th>
                                    <th>Jumlah Pekerja</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{{ $renovation->renovation_start_date }} Hari</td>
                                    <td>{{ $renovation->renovation_end_date}}</td>
                                    <td>{{ $renovation->renovation_start_time}}</td>
                                    <td>{{ $renovation->renovation_end_time}}</td>
                                    <td>{{ $renovation->renovation_duration}}</td>
                                    <td>{{ $renovation->renovation_worker}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <h5 class="lead">Keterangan:</h5>
                        <div class="alert alert-primary mt-20">
                            <p>
                                {!! $renovation->renovation_desc !!}
                            </p>
                        </div>
                    </div>
                    <div class="col-6">
                        <h5 class="lead">Nama Pekerja:</h5>
                        <div class="alert alert-primary mt-20">
                            @php
                            $name = $renovation->renovation_worker_name;
                            $split = explode(',', $name);
                            @endphp
                            <ol>
                                @foreach($split as $item)
                                    <li>{{ ucwords($item) }}</li>
                                @endforeach
                            </ol>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h5 class="lead">Catatan Renovasi:</h5>
                        <div class="alert alert-primary mt-20">
                            <p>
                                {!! $renovation->renovation_remark !!}
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h5 class="lead">Image:</h5>
                        <div class="">
                            <img src="{{ URL::asset('img/'.$renovation->renovation_image) }}" width="100%" height="auto"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ url('tenant-renovation') }}" class="btn btn-md btn-warning"><i class="ik ik-arrow-left"></i>Kembali</a>
                        @if($renovation->status_id == 10)
                        <button class="btn btn-md btn-success" onclick="printArea();"><i class="fa fa-print"></i> Print</button>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
    <script>
        function printArea()
        {
            var options = {  };
            $("#printArea").printArea( options );
        }
    </script>
@endsection