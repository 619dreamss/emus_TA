{{-- <div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="{{ url('/home') }}">Tugas Akhir</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="{{ url('/home') }}">TA</a>
        </div>
        <ul class="sidebar-menu">

            @if(isset($user['role']['menu']))
            @foreach($user['role']['menu'] as $key => $role)
            <li class="menu-header">{{ ucfirst($role['menu_name']) }}</li>
            <li class="nav-item dropdown">
                <a href="{{ $role['menu_url'] }}" class="nav-link {{ (count($role['sub_menu']) > 0)?'has-dropdown':'' }}">{!! $role['menu_icon'] !!}<span>{{ ucfirst($role['menu_name']) }}</span></a>
                <ul class="dropdown-menu">
                    @foreach($role['sub_menu'] as $item)
                    <li class=""><a class="nav-link" href="{{ $item['menu_url'] }}">{{ ucfirst($item['menu_name']) }}</a></li>
                    @endforeach
                </ul>
            </li>
            @endforeach
            @endif
        </ul>
    </aside>
</div> --}}
<div class="app-sidebar colored">
    <div class="sidebar-header">
        <a class="header-brand" href="{{ url('home') }}">
            
            <span class="text">SIPETA</span>
        </a>
        <button type="button" class="nav-toggle"><i data-toggle="expanded" class="ik ik-toggle-right toggle-icon"></i></button>
        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
    </div>


    <div class="app-sidebar colored">
        <div class="sidebar-header">
            <a class="header-brand" href="{{ url('home') }}">
                <span class="text">SIPETA</span>
            </a>
            <button type="button" class="nav-toggle"><i data-toggle="expanded" class="ik ik-toggle-right toggle-icon"></i></button>
            <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
        </div>
        
        <div class="sidebar-content">
            <div class="nav-container">
                <nav id="main-menu-navigation" class="navigation-main">
                    @if(isset($user['role']['menu']))
                    @foreach($user['role']['menu'] as $key => $role)
                    <div class="nav-lavel">{{ $role['menu_name'] }}</div>

                    @if(count($role['sub_menu']) == 0)
                    <div class="nav-item">
                        <a href="{{ url($role['menu_url']) }}">{!! $role['menu_icon'] !!}</i><span>{{$role['menu_name']}}</span></a>
                    </div>
                    @endif

                    @if(count($role['sub_menu']) > 0)
                    <div class="nav-item has-sub">
                        <a href="#">{!! $role['menu_icon'] !!}</i><span>{{ $role['menu_name'] }}</span></a>
                        <div class="submenu-content">
                            @foreach($role['sub_menu'] as $item)
                            <a href="{{ url($item['menu_url']) }}" class="menu-item">{{ $item['menu_name'] }}</a>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    @endforeach
                    @endif
                </nav>
            </div>
        </div>
    </div>
</div>