@extends('main_layout')
@section('content')

<div class="main-content">
    <div class="container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-12">
                    <div class="page-header-title">
                        <i class="ik ik-file-text bg-blue"></i>
                        <div class="d-inline">
                            <h5>IKMB</h5>
                            <span>IKMB Detail.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3 class="d-block w-100">{{ ucwords($loading_item->loading_item_category) }}</h3></div>
            <div class="card-body" id="printArea">
                <div class="row invoice-info">
                    <div class="col-sm-12 invoice-col">
                        <b>No. IKMB #{{ $loading_item->loading_item_number }}</b>
                        <div class="float-right">Tanggal IKMB: {{ date('Y/m/d', strtotime($loading_item->created_at)) }}</div>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nama Tenant</th>
                                    <th>Email</th>
                                    <th>No. Telp</th>
                                    <th>Type ID.</th>
                                    <th>Identitias</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr></tr>
                                    <td>{{ $loading_item->tenant->tenant_name }} Hari</td>
                                    <td>{{ $loading_item->tenant->tenant_email}}</td>
                                    <td>{{ $loading_item->tenant->tenant_phone }}</td>
                                    <td>{{ $loading_item->tenant->tenant_id_type }}</td>
                                    <td>{{ $loading_item->tenant->tenant_id_number }}</td>
                                    <td>{{ $loading_item->tenant->tenant_address }}</td>
                                </tr>
                            </tbody>
                        </table>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Penanggung Jawab</th>
                                    <th>No. Telp</th>
                                    <th>Alamat</th>
                                    <th>Status</th>
                                    <th>Unit</th>
                                    <th>Pengelola</th>
                                    <th>Tanggl & Jam</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{{ $loading_item->loading_item_leader}} Hari</td>
                                    <td>{{ $loading_item->loading_item_phone}}</td>
                                    <td>{{ $loading_item->loading_item_address}}</td>
                                    <td>{{ $loading_item->status->status_name }}</td>
                                    <td>{{ $loading_item->unit->unit_number }}</td>
                                    <td>{{ $loading_item->unit->unit_name }}</td>
                                    <td>{{ date('l, Y/m/d', strtotime($loading_item->loading_item_date)).' '.$loading_item->loading_item_time }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <h5 class="lead">Jenis Barang:</h5>
                        <div class="alert alert-primary mt-20">
                            @php
                            $barang = $loading_item->loading_item_category;
                            $split = explode(',', $barang);
                            @endphp
                            <ol>
                                @foreach ($split as $item)
                                    <li>{{ $item }}</li>
                                @endforeach
                            </ol>
                        </div>
                    </div>
                    <div class="col-6">
                        <h5 class="lead">Nama Pembawa Barang:</h5>
                        <div class="alert alert-primary mt-20">
                            @php
                            $name = $loading_item->loading_item_courier_name;
                            $split = explode(',', $name);
                            @endphp
                            <ol>
                                @foreach ($split as $item)
                                    <li>{{ $item }}</li>
                                @endforeach
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ url('tenant-ikmb') }}" class="btn btn-md btn-warning"><i class="ik ik-arrow-left"></i>Kembali</a>
                        @if($loading_item->status_id == 10)
                        <button class="btn btn-md btn-success" onclick="printArea();"><i class="fa fa-print"></i> Print</button>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
    <script>
        function printArea()
        {
            var options = {  };
            $("#printArea").printArea( options );
        }
    </script>
@endsection