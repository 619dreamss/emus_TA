@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>Form IKMB.</h3></div>
            <div class="card-body">
                {!! Form::model($loadingItem, ['route' => ['tenant-ikmb.update', $loadingItem->loading_item_id], 'method' => 'put']) !!}
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="renovation_desc"><strong>1. Data Tenant</strong></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        @if(strtolower($user['role']['role_name']) == 'tenant')
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="unit_id">Unit</label>
                                <select name="unit_id" id="unit_id" class="form-control">
                                    <option value="">Pilih Unit</option>
                                    @foreach($units as $unit)
                                        <option value="{{ $unit->unit_id }}" {{ ($loadingItem->unit_id == $unit->unit_id)?'selected':'' }} >{{ $unit->unit_number.' - '.$unit->unit_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('unit_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                        @if(strtolower($user['role']['role_name']) != 'tenant')
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group">
                                <label for="status_id"><span class="badge badge-pill badge-danger">Status</span></label>
                                <select name="status_id" id="status_id" class="form-control">
                                    <option value="">Pilih Unit</option>
                                    @foreach($status as $unit)
                                        <option value="{{ $unit->status_id }}" {{ ($loadingItem->status_id == $unit->status_id)?'selected':'' }} >{{$unit->status_name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('status_id'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('status_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <hr>
                                <label for="renovation_desc"><strong>2. Data Barang & Penanggung Jawab</strong></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="loading_item_event">Acara</label></label>
                                <input type="text" name="loading_item_event" class="form-control" placeholder="Kosongkan apabila bukan untuk acara" value="{{ $loadingItem->loading_item_event }}">
                                @if ($errors->has('loading_item_event'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_event') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="loading_item_leader">Nama Penanggung Jawab</label>
                                <input type="text" name="loading_item_leader" class="form-control" placeholder="" value="{{ $loadingItem->loading_item_leader }}">
                                @if ($errors->has('loading_item_leader'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_leader') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="loading_item_phone">No. Telepon Penanggung Jawab</label>
                                <input type="text" name="loading_item_phone" class="form-control" placeholder="eg. 62 8585 1111 222 3333" value="{{ $loadingItem->loading_item_phone }}">
                                @if ($errors->has('loading_item_phone'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="loading_item_address">Alamat</label>
                                <textarea name="loading_item_address" class="form-control" placeholder="" value="{{ old('loading_item_address') }}">{{ $loadingItem->loading_item_address }}</textarea>
                                @if ($errors->has('loading_item_address'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="loading_item_date">Tanggal</label>
                                <input type="date" class="form-control" name="loading_item_date"  value="{{ $loadingItem->loading_item_date }}">
                                @if ($errors->has('loading_item_date'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_date') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="loading_item_time">Jam (Dalam 24)</label>
                                <input type="time" class="form-control" name="loading_item_time"  value="{{ $loadingItem->loading_item_time }}">
                                @if ($errors->has('loading_item_time'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_time') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="loading_item_category">Jenis Barang</label></label>
                                <textarea name="loading_item_category" class="form-control" placeholder="Masukkan semua jenis barang dipisahkan dengan koma(,) tanpa spasi" value="{{ old('loading_item_category') }}">{{ $loadingItem->loading_item_category }}</textarea>
                                @if ($errors->has('loading_item_category'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_category') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="loading_item_courier_name">Nama Pembawa Barang</label></label>
                                <textarea name="loading_item_courier_name" class="form-control" placeholder="Masukkan semua nama pembawa barang dipisahkan dengan koma(,) tanpa spasi" value="{{ old('loading_item_courier_name') }}">{{ $loadingItem->loading_item_courier_name }}</textarea>
                                @if ($errors->has('loading_item_courier_name'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('loading_item_courier_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant-ikmb') }}" class="btn btn-warning"><i class="ik ik-arrow-left"></i> Kembali</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection