@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>Form Unit.</h3></div>
            <div class="card-body">
                {!! Form::model($unit, ['route' => ['tenant-unit.update', $unit->unit_id], 'method' => 'put']) !!}
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label for="unit_number">No. Unit</label>
                                <input type="text" id="unit_number" name="unit_number" class="form-control" placeholder="No. Unit" value="{{ $unit->unit_number }}">
                                @if ($errors->has('unit_number'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label for="unit_name">Perusahaan</label>
                                <input type="text" name="unit_name" class="form-control" placeholder="Nama Perusahaan" value="{{ $unit->unit_name }}">
                                @if ($errors->has('unit_name'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="unit_address">Alamat</label>
                                <textarea type="text" name="unit_address" class="form-control" placeholder="Alamat unit" value="">{{ $unit->unit_address }}</textarea>
                                @if ($errors->has('unit_address'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('unit_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant-unit') }}" class="btn btn-danger"><i class="ik ik-arrow-left"></i> Batal</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection