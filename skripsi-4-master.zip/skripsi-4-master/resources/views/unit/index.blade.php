@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header row">
                <div class="col col-sm-12">
                    {{-- <div class="card-options d-inline-block"> --}}
                        @if(FunctionsHelper::checkRole($menuId, 'create'))
                        <a data-toggle="tooltip" data-placement="left" title="Tambah" href="{{ url('tenant-unit/create') }}" class="badge badge-pill badge-primary">Tambah Unit</a>
                        @endif
                    {{-- </div> --}}
                </div>
            </div>
            <div class="card-body table-responsive">
                <table id="advanced_table" class="table" style="overflow-x: auto">
                    <thead>
                        <tr>
                            <th>No.</th>
                            {{-- <th>Apartement</th> --}}
                            <th>No. Unit</th>
                            {{-- <th>Alamat</th> --}}
                            <th>Aksi</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($units as $key => $item)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            {{-- <td>{{ ucwords($item->unit_name) }}</td> --}}
                            <td>{{ $item->unit_number }}</td>
                            {{-- <td>{{ $item->unit_address }}</td> --}}
                            <td width="100px">
                                {{-- @if(FunctionsHelper::checkAction($menuId, 'edit')) --}}
                                    <a href="{{ URL::to('tenant-unit/edit/'.$item->unit_id) }}" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-icon btn-warning"><i class="ik ik-edit"></i></a>
                                {{-- @endif --}}
                                @if(FunctionsHelper::checkAction($menuId, 'delete'))
                                    <button data-href="{{ URL::to('tenant/delete/'.$item->unit_id) }}" data-placement="right" data-toggle="modal" data-target="#confirmationDelete" title="Delete" class="btn btn-icon btn-danger" onclick="confirmationDelete(this)"><i class="ik ik-trash"></i></button>
                                @endif
                                @if(FunctionsHelper::checkAction($menuId, 'create'))
                                    <a href="{{ URL::to('tenant-unit/'.$item->unit_id) }}" data-toggle="tooltip" data-placement="left" title="Tambah Unit" class="btn btn-icon btn-success"><i class="ik ik-home"></i></a>
                                @endif
                            </td>
                            <td>&nbsp;</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection