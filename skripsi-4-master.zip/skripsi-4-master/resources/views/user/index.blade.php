@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header row">
                <div class="col col-sm-12">
                    <div class="card-options d-inline-block">
                        @if(FunctionsHelper::checkRole($menuId, 'create'))
                        <a data-toggle="tooltip" data-placement="left" title="Tambah" href="{{ url('user/add') }}"><i class="ik ik-plus"></i></a>
                        @endif
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table id="advanced_table" class="table">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Action</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($users as $key => $user)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            <td>{{ ucwords($user->name) }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ isset($user->role->roles_name)?ucwords($user->role->roles_name):'-' }}</td>
                            <td>{{ ($user->status == 1)?'Active':'In Active' }}</td>
                            <td>
                                @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                <a href="{{ URL::to('user/edit/'.$user->id) }}" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-icon btn-warning"><i class="ik ik-edit"></i></a>
                                @endif
                                @if(FunctionsHelper::checkAction($menuId, 'deleted'))
                                <button data-href="{{ URL::to('user/delete/'.$user->id) }}" data-placement="right" data-toggle="modal" data-target="#confirmationDelete" title="Delete" class="btn btn-danger" onclick="confirmationDelete(this)"><i class="ik ik-trash"></i></button>
                                @endif
                            </td>
                            <td></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection