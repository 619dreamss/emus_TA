@extends('main_layout')
@section('content')

<div class="main-content">
    <div class="container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-12">
                    <div class="page-header-title">
                        <i class="ik ik-file-text bg-blue"></i>
                        <div class="d-inline">
                            <h5>Invoice</h5>
                            <span>Silahkan melakukan pembayaran sebelum tenggat waktu.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3 class="d-block w-100">{{ ucwords($invoice->invoice_category) }}<small class="float-right">Tanggal Invoice: {{ date('Y/m/d', strtotime($invoice->created_at)) }}</small></h3></div>
            <div class="card-body">
                <div class="row invoice-info">
                    <div class="col-sm-4 invoice-col">
                        From
                        <address>
                            <strong>{{ ucwords($invoice->tenant->unit->unit_name) }}</strong><br>
                            {{ ucwords($invoice->tenant->unit->unit_address) }}
                        </address>
                    </div>
                    <div class="col-sm-4 invoice-col">
                        To
                        <address>
                            @php
                            $userDetail = $invoice->tenant;
                            @endphp
                            <strong>{{ ucwords($userDetail->tenant_name) }}</strong>
                            <br>{!! $userDetail->user_detail_address !!}
                        </address>
                    </div>
                    <div class="col-sm-4 invoice-col">
                        <b>Invoice #{{ $invoice->invoice_number }}</b><br>
                        <b>Payment Due:</b> {{ date('Y/m/d', strtotime($invoice->invoice_payment_timelimit)) }}
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Qty</th>
                                    <th>No. Unit</th>
                                    <th>Jenis Tagihan</th>
                                    <th>Bulan Tagihan</th>
                                    <th>Status Pembayaran</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>{{ $invoice->unit->unit_number }}</td>
                                    <td>{{ $invoice->invoice_category }}</td>
                                    <td>{{ $invoice->invoice_month }}</td>
                                    <td>{{ $invoice->status->status_name }}</td>
                                    <td>IDR. {{ number_format($invoice->invoice_amount) }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <p class="lead">Payment Methods:</p>
                        <img src="{{ URL::asset('/img/credit/visa.png') }}" alt="Visa">
                        
                        <div class="alert alert-success mt-20">
                            No. Virtual Account Pembayaran
                            <h4>{{ $invoice->invoice_va_number }}</h4>
                        </div>

                        <p class="lead">Catatan Khusus:</p>
                        <div class="alert alert-primary mt-20">
                            <p>
                                {!! $invoice->invoice_remark !!}
                            </p>
                        </div>
                    </div>
                    <div class="col-6">
                        <p class="lead">Tenggat Waktu : <span class="badge badge-pill badge-danger">{{ date('Y/m/d', strtotime($invoice->invoice_payment_timelimit)) }}</span></p>
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <th style="width:50%">Biaya Pemakaian Bulan {{ $invoice->invoice_month }}:</th>
                                    <td>{{ number_format($invoice->invoice_amount) }}</td>
                                </tr>
                                <tr>
                                    <th style="width:50%">Biaya PPN (10%):</th>
                                    <td>{{ number_format($invoice->invoice_ppn) }}</td>
                                </tr>
                                <tr>
                                    <th>Total:</th>
                                    <td>{{ number_format($invoice->invoice_amount + $invoice->invoice_ppn) }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <a href="{{ url('tenant-invoice') }}" class="btn btn-md btn-warning"><i class="ik ik-arrow-left"></i>Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection