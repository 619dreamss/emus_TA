@extends('main_layout')
@section('content')
<div class="main-content">
    <div class="container-fluid">
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{session('success')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{session('error')}}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ik ik-x"></i>
            </button>
        </div>
        @endif

        <div class="card">
            <div class="card-header"><h3>Form Invoice.</h3></div>
            <div class="card-body">
                {!! Form::model($invoice, ['route' => ['tenant-invoice.update', $invoice->invoice_id], 'method' => 'put']) !!}
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="invoice_number">No. Invoice</label>
                                <input type="text" id="invoice_number" name="invoice_number" class="form-control" placeholder="" value="{{ $invoice->invoice_number }}" disabled>
                                @if ($errors->has('invoice_number'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="invoice_number">Unit</label>
                                <input type="text" id="invoice_number" name="invoice_number" class="form-control" placeholder="" value="{{ $invoice->unit->unit_number }}" disabled>
                                @if ($errors->has('invoice_number'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="invoice_category">Jenis Tagihan</label>
                                <select name="invoice_category" id="invoice_category" class="form-control">
                                    <option value="">Pilih Jenis Tagihan</option>
                                    <option value="Listrik" {{ ($invoice->invoice_category == 'Listrik')?'selected':'' }}>Listrik</option>
                                    <option value="Air" {{ ($invoice->invoice_category == 'Air')?'selected':'' }}>Air</option>
                                    <option value="Service Charge" {{ ($invoice->invoice_category == 'Service Charge')?'selected':'' }}>Service Charge</option>
                                </select>
                                @if ($errors->has('invoice_category'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_category') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-group">
                                <label for="status_id" class="badge badge-pill badge-warning">Status Pembayaran</label>
                                <select name="status_id" id="status_id" class="form-control">
                                    @foreach($status as $item)
                                    <option value="{{ $item->status_id }}" {{ ($invoice->status_id == $item->status_id)?'selected':'' }}>{{ $item->status_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="invoice_amount">Jumlah Tagihan</label>
                                <input type="text" name="invoice_amount" class="form-control" placeholder="" value="{{ $invoice->invoice_amount }}">
                                @if ($errors->has('invoice_amount'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_amount') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <label for="invoice_month">Bulan Tagihan</label>
                            <select class="form-control" name="invoice_month" required>
                                <option value="">Silahkan pilih bulan</option>
                                <option value="{{ 'Januari, '.date('Y') }}" {{ ($invoice->invoice_month == 'Januari, '.date('Y'))?'selected':'' }}>{{ 'Januari, '.date('Y') }}</option>
                                <option value="{{ 'Februari, '.date('Y') }}" {{ ($invoice->invoice_month == 'Februari, '.date('Y'))?'selected':'' }}>{{ 'Februari, '.date('Y') }}</option>
                                <option value="{{ 'Maret, '.date('Y') }}" {{ ($invoice->invoice_month == 'Maret, '.date('Y'))?'selected':'' }}>{{ 'Maret, '.date('Y') }}</option>
                                <option value="{{ 'April, '.date('Y') }}" {{ ($invoice->invoice_month == 'April, '.date('Y'))?'selected':'' }}>{{ 'April, '.date('Y') }}</option>
                                <option value="{{ 'Mei, '.date('Y') }}" {{ ($invoice->invoice_month == 'Mei, '.date('Y'))?'selected':'' }}>{{ 'Mei, '.date('Y') }}</option>
                                <option value="{{ 'Juni, '.date('Y') }}" {{ ($invoice->invoice_month == 'Juni, '.date('Y'))?'selected':'' }}>{{ 'Juni, '.date('Y') }}</option>
                                <option value="{{ 'Juli, '.date('Y') }}" {{ ($invoice->invoice_month == 'Juli, '.date('Y'))?'selected':'' }}>{{ 'Juli, '.date('Y') }}</option>
                                <option value="{{ 'Agustus, '.date('Y') }}" {{ ($invoice->invoice_month == 'Agustus, '.date('Y'))?'selected':'' }}>{{ 'Agustus, '.date('Y') }}</option>
                                <option value="{{ 'September, '.date('Y') }}" {{ ($invoice->invoice_month == 'September, '.date('Y'))?'selected':'' }}>{{ 'September, '.date('Y') }}</option>
                                <option value="{{ 'Oktober, '.date('Y') }}" {{ ($invoice->invoice_month == 'Oktober, '.date('Y'))?'selected':'' }}>{{ 'Oktober, '.date('Y') }}</option>
                                <option value="{{ 'November, '.date('Y') }}" {{ ($invoice->invoice_month == 'November, '.date('Y'))?'selected':'' }}>{{ 'November, '.date('Y') }}</option>
                                <option value="{{ 'Desember, '.date('Y') }}" {{ ($invoice->invoice_month == 'Desember, '.date('Y'))?'selected':'' }}>{{ 'Desember, '.date('Y') }}</option>
                                @if ($errors->has('invoice_month'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_month') }}</strong>
                                    </span>
                                @endif
                            </select>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="invoice_payment_timelimit">Tenggat Waktu</label>
                                <input type="date" name="invoice_payment_timelimit" class="form-control" placeholder="" value="{{ $invoice->invoice_payment_timelimit }}">
                                @if ($errors->has('invoice_payment_timelimit'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_payment_timelimit') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int">
                                <label for="invoice_remark">Keterangan / Catatan Khusus</label>
                                <textarea name="invoice_remark" class="form-control" placeholder="Masukkan informasi tambahan disini.">
                                    {{ $invoice->invoice_remark }}
                                </textarea>
                                @if ($errors->has('invoice_remark'))
                                    <span class="help-block error">
                                        <strong>{{ $errors->first('invoice_remark') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('tenant-invoice') }}" class="btn btn-warning"><i class="ik ik-arrow-left"></i> Simpan</a>
                            <button class="btn btn-success"><i class="ik ik-check-circle"></i> Simpan</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection