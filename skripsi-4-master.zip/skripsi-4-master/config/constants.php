<?php

return [
    'REDIS_ACCESS' => 'user_access_4_',
    'IMAGE_PATH' => '/Users/arak/Documents/MY DOCS/WEB/TA/skripsi-3/public/assets/img/',
    'IMAGE_URL' => 'http://localhost/asset/'
];