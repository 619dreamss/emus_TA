<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RolePermission extends Model
{
    protected $table = 'role_permission';

    public function permissions()
    {
        return $this->hasOne('App\Permission', 'permissions_id', 'permission_id');
    }
}
