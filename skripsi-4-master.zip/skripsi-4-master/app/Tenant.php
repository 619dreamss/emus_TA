<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tenant extends Model
{
    protected $table = 'tenant';
    protected $primaryKey = 'tenant_id';

    public function user()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function unit()
    {
        return $this->hasOne('App\Unit', 'tenant_id', 'tenant_id');
    }

    public function units()
    {
        return $this->hasMany('App\Unit', 'tenant_id', 'tenant_id');
    }
}
