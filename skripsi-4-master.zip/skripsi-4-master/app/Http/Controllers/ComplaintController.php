<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Complaint;
use App\Unit;
use App\Status;
use App\Helpers\FunctionsHelper;
use Validator;
use DB;

class ComplaintController extends Controller
{
    protected $role;
    protected $hasAccess;
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        if (empty($dataRedis)) 
        {
            return redirect('logout');
        }
        $this->role = $dataRedis['role']['role_name'];
        $this->hasAccess = FunctionsHelper::checkRole('tenant-complaint');
        $menuId = $this->hasAccess['menu_id'];

        $complaint = Complaint::with('tenant')->with('unit')->orderBy('complaint_id', 'desc');
        if (strtoupper($this->role) == 'TENANT') {
            $complaint->where('tenant_id', $dataRedis['user_id']);
        }
        if (strtoupper($this->role) == 'ENGINEERING') {
            $complaint->where('status_id', [3,9,10]);
        }
        $complaints = $complaint->get();
        return view('complaint.index', compact('complaints', 'menuId'));
    }

    public function create()
    {
        $category = [
            ["name" => 'AC'],
            ["name" => 'Electrical'],
            ["name" => 'Plumbing'],
            ["name" => 'Lainnya'],
        ];
        
        $dataRedis = FunctionsHelper::dataRedis();
        $units = Unit::where('tenant_id', $dataRedis['user_id'])->get();
        return view('complaint.create', compact('units', 'category'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'complaint_category' => 'required',
            'unit_id' => 'required',
            'complaint_remark' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {
            $dataRedis = FunctionsHelper::dataRedis();
            $complaint = new Complaint();
            $complaint->complaint_category = $request->complaint_category;
            $complaint->unit_id = $request->unit_id;
            $complaint->tenant_id = $dataRedis['user_id'];
            $complaint->complaint_remark = $request->complaint_remark;
            $complaint->status_id = 4; // PENDING
            $complaint->save();

            $lastId = $complaint->complaint_id;
            $no = sprintf("%05d", $lastId);
            $number = $no.'/CR-KL'.'/'.date('m/Y');
            Complaint::where('complaint_id', $lastId)->update([
                'complaint_number' => $number
            ]);
            
            DB::commit();
            return redirect('tenant-complaint')->with('success', 'Komplain berhasil dibuat.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $category = [
            ["name" => 'AC'],
            ["name" => 'Electrical'],
            ["name" => 'Plumbing'],
            ["name" => 'Lainnya'],
        ];
        
        $dataRedis = FunctionsHelper::dataRedis();
        $units = Unit::where('tenant_id', $dataRedis['user_id'])->get();
        $complaint = Complaint::where('complaint_id', $id)->first();

        if (strtolower($dataRedis['role']['role_name']) == 'cr') {
            $status = Status::whereIn('status_id', [3, 4])->get();
        } else if (strtolower($dataRedis['role']['role_name']) == 'engineering') {
            $status = Status::whereIn('status_id', [3, 5])->get();
        } else {
            $status = Status::where('status_type_id', 1)->get();
        }

        return view('complaint.edit', compact('units', 'category', 'complaint', 'status'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'complaint_category' => 'required',
            'complaint_remark' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {

            $param['complaint_category'] = $request->complaint_category;
            $param['complaint_remark'] = $request->complaint_remark;
            if (isset($request->status_id)) {
                $param['status_id'] = $request->status_id;
            }
            if (isset($request->unit_id)) {
                $param['unit_id'] = $request->unit_id;
            }
            if (isset($request->complaint_priority)) {
                $param['complaint_priority'] = $request->complaint_priority;
            }

            Complaint::where('complaint_id', $id)->update($param);
            
            DB::commit();
            return redirect('tenant-complaint')->with('success', 'Komplain berhasil dibuat.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function show()
    {
        return "ok";
    }

    public function detail($id)
    {
        $complaint = Complaint::with('tenant')
            ->where('complaint_id', $id)
            ->with('status')
            ->with('unit')->first();
        return view('complaint.detail', compact('complaint'));
    }
}
