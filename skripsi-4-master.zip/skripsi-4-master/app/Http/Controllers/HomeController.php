<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Auth;
use App\Helpers\FunctionsHelper;
use App\User;
use Route;
use App\Renovation;
use App\LoadingItem;
use App\Complaint;
use App\Tenant;

class HomeController extends Controller
{
    protected $isRole;
    public function __construct()
    {
        $this->middleware(['auth']);
    }
    
    public function index()
    {
        $route = Route::current()->uri();
        $this->isRole = $isRole = FunctionsHelper::checkRole($route);
        $menuId = $this->isRole['menu_id'];
        if ($this->isRole['status'] == false) {
            return "Anda tidak mempunyai akses untuk sistem ini";
        }

        $tenant = Tenant::count();
        $renovation = Renovation::count();
        $complaint = Complaint::count();
        $ikmb = LoadingItem::count();
        
        return view('home.index', compact('menuId', 'tenant', 'renovation', 'complaint', 'ikmb'));
    }
}
