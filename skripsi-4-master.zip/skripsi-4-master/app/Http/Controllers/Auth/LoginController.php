<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

use Illuminate\Http\Request;
use App\User;
use Session;
use URL;
use App\Helpers\FunctionsHelper;
use Illuminate\Support\Facades\Redis;
use Validator;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    // use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function index()
    {
        return view('auth.login');
    }

    public function login()
    {
        return redirect(URL::to('/'));
    }

    public function doLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withInput()->withErrors($validator);
        }

        $user = User::where('email', $request->email)->active()->first();
        if (empty($user)) {
            return redirect()->back()->with('error', 'Email tidak terdaftar');
        }
        if (FunctionsHelper::hashPassword($request->password) != $user->password) {
            return redirect()->back()->with('error', 'Password Salah');
        }
        $user['id'] = $user->id;
        $user['username'] = $user->email;
        $user['password'] = $request->password;
        $auth = Auth::login($user);

        $userAccess = FunctionsHelper::userDetail($user);
        if (empty($userAccess || !$userAccess)) {
            self::logout();
            return redirect()->back();
        }

        Redis::set(config('constants.REDIS_ACCESS').$user->id, json_encode($userAccess));
        return redirect(URL::to('home'));
    }

    public function logout()
    {
        $user = Auth::user();
        if (!is_null($user)) {
            Redis::del(config('constants.REDIS_ACCESS').$user->id);
        }
        Auth::logout();
        Session::flush();

        return redirect(URL::to('/'));
    }

    public function register()
    {
        return view('auth.register');
    }

    public function doRegister(Request $request)
    {
        return $request->all();
    }
}
