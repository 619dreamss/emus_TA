<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Validator;
use App\Unit;
use App\Renovation;
use App\Status;
use App\Helpers\FunctionsHelper;
use Intervention\Image\Facades\Image;

class RenovationController extends Controller
{
    protected $role;
    protected $hasAccess;
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        if (empty($dataRedis)) 
        {
            return redirect('logout');
        }
        $this->role = $dataRedis['role']['role_name'];
        $this->hasAccess = FunctionsHelper::checkRole('tenant-renovation');
        $menuId = $this->hasAccess['menu_id'];

        $renovation = Renovation::with('tenant')->with('unit')->orderBy('renovation_id', 'desc');
        if (strtoupper($this->role) == 'TENANT') {
            $renovation->where('tenant_id', $dataRedis['user_id']);
        }
        if (strtoupper($this->role) == 'IMPROVEMENT') {
            $renovation->whereIn('status_id', [3,9,10]);
        }
        $renovations = $renovation->get();
        return view('renovation.index', compact('renovations', 'menuId'));
    }

    public function create()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $units = Unit::where('tenant_id', $dataRedis['user_id'])->get();
        return view('renovation.create', compact('units'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'unit_id' => 'required',
            'renovation_desc' => 'required',
            'renovation_start_date' => 'required',
            'renovation_end_date' => 'required',
            'renovation_company_name' => 'required',
            'renovation_contractor_leader' => 'required',
            'renovation_contractor_phone' => 'required|numeric',
            'renovation_contractor_id' => 'required|numeric',
            'renovation_contractor_address' => 'required',
            'renovation_start_time' => 'required',
            'renovation_end_time' => 'required',
            'renovation_duration' => 'required|numeric',
            'renovation_worker' => 'required|numeric',
            'renovation_worker_name' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {
            $file = $request->file('renovation_image');
            $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $canvas = Image::canvas('600', '400');
            $resizeThumbs  = Image::make($file)->resize('600', '400', function($constraint) {
                $constraint->aspectRatio();
            });
            $canvas->insert($resizeThumbs, 'center');
            $canvas->save(config('constants.IMAGE_PATH') . $fileName);

            $dataRedis = FunctionsHelper::dataRedis();
            $renovation = new Renovation();
            $renovation->unit_id = $request->unit_id;
            $renovation->tenant_id = $dataRedis['user_id'];
            $renovation->renovation_desc = $request->renovation_desc;
            $renovation->renovation_start_date = $request->renovation_start_date;
            $renovation->renovation_end_date = $request->renovation_end_date;
            $renovation->status_id = 4; // PENDING
            $renovation->renovation_company_name = $request->renovation_company_name;
            $renovation->renovation_contractor_leader = $request->renovation_contractor_leader;
            $renovation->renovation_contractor_phone = $request->renovation_contractor_phone;
            $renovation->renovation_contractor_id = $request->renovation_contractor_id;
            $renovation->renovation_contractor_address = $request->renovation_contractor_address;
            $renovation->renovation_start_time = $request->renovation_start_time;
            $renovation->renovation_end_time = $request->renovation_end_time;
            $renovation->renovation_duration = $request->renovation_duration;
            $renovation->renovation_worker = $request->renovation_worker;
            $renovation->renovation_worker_name = $request->renovation_worker_name;
            $renovation->renovation_image = $fileName;
            $renovation->save();

            $lastId = $renovation->renovation_id;
            $no = sprintf("%05d", $lastId);
            $number = $no.'/CR-IR'.'/'.date('m/Y');
            Renovation::where('renovation_id', $lastId)->update([
                'renovation_approval_number' => $number
            ]);
            
            DB::commit();
            return redirect('tenant-renovation')->with('success', 'Data Renovasi berhasil dibuat.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $units = Unit::where('tenant_id', $dataRedis['user_id'])->get();
        $renovation = renovation::where('renovation_id', $id)->first();
        if (strtolower($dataRedis['role']['role_name']) == 'cr') {
            $status = Status::whereIn('status_id', [3, 4])->get();
        } else if (strtolower($dataRedis['role']['role_name']) == 'improvement') {
            $status = Status::whereIn('status_id', [3, 10])->get();
        } else {
            $status = Status::where('status_type_id', 1)->get();
        }
        return view('renovation.edit', compact('units', 'renovation', 'status'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'renovation_desc' => 'required',
            'renovation_start_date' => 'required',
            'renovation_end_date' => 'required',
            'renovation_company_name' => 'required',
            'renovation_contractor_leader' => 'required',
            'renovation_contractor_phone' => 'required|numeric',
            'renovation_contractor_id' => 'required|numeric',
            'renovation_contractor_address' => 'required',
            'renovation_start_time' => 'required',
            'renovation_end_time' => 'required',
            'renovation_duration' => 'required|numeric',
            'renovation_worker' => 'required|numeric',
            'renovation_worker_name' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {
            if (isset($request->unit_id)) {
                $param['unit_id'] = $request->unit_id;
            }
            if (isset($request->renovation_remark)) {
                $param['renovation_remark'] = $request->renovation_remark;
            }
            $param['renovation_desc'] = $request->renovation_desc;
            $param['renovation_start_date'] = $request->renovation_start_date;
            $param['renovation_end_date'] = $request->renovation_end_date;
            $param['renovation_company_name'] = $request->renovation_company_name;
            $param['renovation_contractor_leader'] = $request->renovation_contractor_leader;
            $param['renovation_contractor_phone'] = $request->renovation_contractor_phone;
            $param['renovation_contractor_id'] = $request->renovation_contractor_id;
            $param['renovation_contractor_address'] = $request->renovation_contractor_address;
            $param['renovation_start_time'] = $request->renovation_start_time;
            $param['renovation_end_time'] = $request->renovation_end_time;
            $param['renovation_duration'] = $request->renovation_duration;
            $param['renovation_worker'] = $request->renovation_worker;
            $param['renovation_worker_name'] = $request->renovation_worker_name;
            if (isset($request->status_id)) {
                $param['status_id'] = $request->status_id;
            }
            Renovation::where('renovation_id', $id)->update($param);
            
            DB::commit();
            return redirect('tenant-renovation')->with('success', 'Data Renovasi berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function detail($id)
    {
        $renovation = Renovation::with(['status', 'tenant', 'unit'])->where('renovation_id', $id)->first();
        return view('renovation.detail', compact('renovation'));
    }
}
