<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tenant;
use App\Unit;
use App\User;
use App\Role;
use App\Renovation;
use App\Complaint;
use App\LoadingItem;
use App\Invoice;
use App\Helpers\FunctionsHelper;
use Validator;
use DB;

class TenantController extends Controller
{
    protected $role;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $this->role = $dataRedis['role']['role_name'];
        $this->isRole = $isRole = FunctionsHelper::checkRole('tenant');
        $menuId = $this->isRole['menu_id'];
        $tenant = Tenant::with(['user' => function($query) {
        }])
        ->with('units');
        if (strtoupper($this->role) == 'TENANT') {
            $tenant->where('tenant_id', $dataRedis['user_id']);
        }
        $tenants = $tenant->get();

        return view('tenant.index', compact('tenants', 'menuId'));
    }

    public function create()
    {
        $units = Unit::whereNull('tenant_id')->get();
        return view('tenant.create', compact('units'));
    }

    public function createUnit($id)
    {
        $units = Unit::whereNull('tenant_id')->get();
        return view('tenant.unit', compact('id', 'units'));
    }

    public function invoice($id)
    {
        $units = Unit::where('tenant_id', $id)->get();
        return view('tenant.invoice', compact('id', 'units'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'password' => 'required|min:6',
            'tenant_email' => 'required|email|unique:tenant',
            'tenant_phone' => 'required|numeric',
            'tenant_id_type' => 'required',
            'tenant_id_number' => 'required|numeric',
            'tenant_address' => 'required',
            'unit_id' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        DB::beginTransaction();
        try {

            $password = FunctionsHelper::hashPassword($request->password);
            $role = Role::where('roles_name', 'like' ,'%tenant%')->first();
            $user = new User();
            $user->name = $request->name;
            $user->email = $request->tenant_email;
            $user->password = $password;
            $user->role_id = $role->roles_id;
            $user->status = 1;
            $user->save();

            $tenant = new Tenant();
            $tenant->tenant_id = $user->id;
            $tenant->tenant_name = $request->name;
            $tenant->tenant_email = $request->tenant_email;
            $tenant->tenant_password = $password;
            $tenant->tenant_phone = $request->tenant_phone;
            $tenant->tenant_id_number = $request->tenant_id_number;
            $tenant->tenant_id_type = $request->tenant_id_type;
            $tenant->tenant_address = $request->tenant_address;
            $tenant->save();

            Unit::where('unit_id', $request->unit_id)->update([
                'tenant_id' => $tenant->tenant_id
            ]);

            DB::commit();
            return redirect('tenant')->with('success', 'Data tenant berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->with('error', $th->getMessage())
                ->withInput();
        }
    }

    public function edit($id)
    {
        $units = Unit::where('tenant_id', $id)->get();
        $tenant = Tenant::where('tenant_id', $id)->first();
        return view('tenant.edit', compact('tenant', 'units'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'tenant_email' => 'required|email',
            'tenant_phone' => 'required|numeric',
            'tenant_id_type' => 'required',
            'tenant_id_number' => 'required|numeric',
            'tenant_address' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        DB::beginTransaction();
        try {

            $paramUser['name'] = $request->name;
            $paramUser['email'] = $request->tenant_email;
            
            $paramTenant['tenant_name'] = $request->name;
            $paramTenant['tenant_email'] = $request->tenant_email;
            $paramTenant['tenant_phone'] = $request->tenant_phone;
            $paramTenant['tenant_id_number'] = $request->tenant_id_number;
            $paramTenant['tenant_id_type'] = $request->tenant_id_type;
            $paramTenant['tenant_address'] = $request->tenant_address;

            if (!is_null($request->tenant_password)) {
                $password = FunctionsHelper::hashPassword($request->password);
                $paramUser['password'] = $request->password;
                $paramTenant['tenant_password'] = $request->password;
            }

            User::where('id', $id)->update($paramUser);
            Tenant::where('tenant_id', $id)->update($paramTenant);

            DB::commit();
            return redirect('tenant')->with('success', 'Data tenant berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->with('error', $th->getMessage())
                ->withInput();
        }
    }

    public function destroy($id)
    {
        DB::beginTransaction();
        try {

            User::where('id', $id)->delete();
            Invoice::where('tenant_id', $id)->delete();
            Renovation::where('tenant_id', $id)->delete();
            LoadingItem::where('tenant_id', $id)->delete();
            Complaint::where('tenant_id', $id)->delete();
            Unit::where('tenant_id', $id)->update([
                'tenant_id' => null
            ]);
            Tenant::where('tenant_id', $id)->delete();

            DB::commit();
            return redirect()->back()->with('success', 'Date berhasil dihapus.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    public function storeUnit(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'unit_id' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator);
        }

        try {
            Unit::where('unit_id', $request->unit_id)->update([
                'tenant_id' => $request->tenant_id
            ]);
            return redirect('tenant')->with('success', 'Data unit berhasil ditambahkan.');
        } catch (\Throwable $th) {
            return redirect()->back()
                ->with('error', $th->getMessage())
                ->withInput();
        }
    }
}
