<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\FunctionsHelper;
use App\LoadingItem;
use App\Status;
use App\Tenant;
use App\Unit;
use Validator;
use DB;

class LoadingItemController extends Controller
{
    protected $role;
    protected $hasAccess;
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        if (empty($dataRedis)) 
        {
            return redirect('logout');
        }
        $this->role = $dataRedis['role']['role_name'];
        $this->hasAccess = FunctionsHelper::checkRole('tenant-loadingItem');
        $menuId = $this->hasAccess['menu_id'];

        $loadingItem = LoadingItem::with('tenant')->with('unit')->orderBy('loading_item_id', 'desc');
        if (strtoupper($this->role) == 'TENANT') {
            $loadingItem->where('tenant_id', $dataRedis['user_id']);
        }
        $loadingItems = $loadingItem->get();
        return view('loading_item.index', compact('loadingItems', 'menuId'));
    }

    public function create()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $units = Unit::where('tenant_id', $dataRedis['user_id'])->get();
        return view('loading_item.create', compact('units'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'unit_id' => 'required',
            'loading_item_leader' => 'required',
            'loading_item_phone' => 'required',
            'loading_item_address' => 'required',
            'loading_item_event' => 'required',
            'loading_item_date' => 'required',
            'loading_item_time' => 'required',
            'loading_item_category' => 'required',
            'loading_item_courier_name' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {
            $dataRedis = FunctionsHelper::dataRedis();
            $loadingItem = new loadingItem();
            $loadingItem->unit_id = $request->unit_id;
            $loadingItem->tenant_id = $dataRedis['user_id'];
            $loadingItem->loading_item_leader = $request->loading_item_leader;
            $loadingItem->loading_item_phone = $request->loading_item_phone;
            $loadingItem->loading_item_address = $request->loading_item_address;
            $loadingItem->loading_item_event = $request->loading_item_event;
            $loadingItem->loading_item_date = $request->loading_item_date;
            $loadingItem->loading_item_time = $request->loading_item_time;
            $loadingItem->loading_item_category = $request->loading_item_category;
            $loadingItem->loading_item_courier_name = $request->loading_item_courier_name;
            $loadingItem->status_id = 4; // PENDING
            $loadingItem->save();

            $lastId = $loadingItem->loading_item_id;
            $no = sprintf("%05d", $lastId);
            $number = $no.'/CR-IKMB'.'/'.date('m/Y');
            loadingItem::where('loading_item_id', $lastId)->update([
                'loading_item_number' => $number
            ]);
            
            DB::commit();
            return redirect('tenant-ikmb')->with('success', 'IKMB berhasil dibuat.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $units = Unit::where('tenant_id', $dataRedis['user_id'])->get();
        $loadingItem = LoadingItem::where('loading_item_id', $id)->first();
        if (strtolower($dataRedis['role']['role_name']) == 'cr') {
            $status = Status::whereIn('status_id', [4, 10])->get();
        } else {
            $status = Status::where('status_type_id', 1)->get();
        }
        return view('loading_item.edit', compact('units', 'loadingItem', 'status'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'loading_item_leader' => 'required',
            'loading_item_phone' => 'required',
            'loading_item_address' => 'required',
            'loading_item_event' => 'required',
            'loading_item_date' => 'required',
            'loading_item_time' => 'required',
            'loading_item_category' => 'required',
            'loading_item_courier_name' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {
            if (isset($request->unit_id)) {
                $param['unit_id'] = $request->unit_id;
            }
            $param['loading_item_leader'] = $request->loading_item_leader;
            $param['loading_item_phone'] = $request->loading_item_phone;
            $param['loading_item_address'] = $request->loading_item_address;
            $param['loading_item_event'] = $request->loading_item_event;
            $param['loading_item_date'] = $request->loading_item_date;
            $param['loading_item_time'] = $request->loading_item_time;
            $param['loading_item_category'] = $request->loading_item_category;
            $param['loading_item_courier_name'] = $request->loading_item_courier_name;

            if (isset($request->status_id)) {
                $param['status_id'] = $request->status_id;
            }
            loadingItem::where('loading_item_id', $id)->update($param);
            
            DB::commit();
            return redirect('tenant-ikmb')->with('success', 'IKMB berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function show()
    {
        return "ok";
    }

    public function detail($id)
    {
        $loading_item = LoadingItem::with('tenant')->with('unit')
            ->with('status')
            ->where('loading_item_id', $id)
            ->first();
        return view('loading_item.detail', compact('loading_item'));
    }
}
