<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Invoice;
use App\Helpers\FunctionsHelper;
use Validator;
use App\Status;
use DB;

class InvoiceController extends Controller
{
    public function __constructs()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $this->isRole = $isRole = FunctionsHelper::checkRole('tenant-invoice');
        $menuId = $this->isRole['menu_id'];
        $invoice = Invoice::with(['tenant' => function($query) {
            $query->with('unit');
        }])
        ->with('status')
        ->with('unit')
        ->orderBy('invoice_id', 'DESC');
        if (strtolower($dataRedis['role']['role_name']) == 'tenant') {
            $invoice->where('tenant_id', $dataRedis['user_id']);
        }
        $invoices = $invoice->get();

        return view('invoice.index', compact('invoices', 'menuId'));
    }

    public function detail($id, $unit_id)
    {
        $invoice = Invoice::with(['tenant' => function($query) {
            $query->with('unit');
        }])
        ->with('status')
        ->where('invoice_id', $id)
        ->where('unit_id', $unit_id)
        ->first();

        return view('invoice.detail', compact('invoice'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'invoice_number' => 'required',
            'invoice_category' => 'required',
            'invoice_amount' => 'required|numeric',
            'invoice_month' => 'required',
            'invoice_payment_timelimit' => 'required',
            'unit_id' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        DB::beginTransaction();
        try {
            $ppn = 10;
            $amountPpn = ($request->invoice_amount * $ppn)/100;

            $invoice = new Invoice();
            $invoice->tenant_id = $request->tenant_id;
            $invoice->unit_id = $request->unit_id;
            $invoice->status_id = 6; // UNPAID
            $invoice->invoice_va_number = '4567 9098 7654 5678';
            $invoice->invoice_ppn = $amountPpn;
            $invoice->invoice_category = $request->invoice_category;
            $invoice->invoice_amount = $request->invoice_amount;
            $invoice->invoice_month = $request->invoice_month;
            $invoice->invoice_remark = $request->invoice_remark;
            $invoice->invoice_payment_timelimit = $request->invoice_payment_timelimit;
            $invoice->save();

            $lastId = $invoice->invoice_id;
            $no = sprintf("%05d", $lastId);
            $invoiceNumber = $no.'/FA-INV'.'/'.date('m/Y');
            $invoiceNumber = Invoice::where('invoice_id', $lastId)->update(
                [
                    'invoice_number' => $invoiceNumber
                ]
            );

            DB::commit();
            return redirect('tenant-invoice')->with('success', 'Invoice baru berhasil dibuat.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $status = Status::where('status_type_id', 2)->get();
        $invoice = Invoice::where('invoice_id', $id)->first();
        return view('invoice.edit', compact('invoice', 'status'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            // 'invoice_number' => 'required',
            'invoice_category' => 'required',
            'invoice_amount' => 'required|numeric',
            'invoice_month' => 'required',
            'invoice_payment_timelimit' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withInput()
                ->withErrors($validator);
        }

        try {
            $ppn = 10;
            $amountPpn = ($request->invoice_amount * $ppn)/100;
            
            Invoice::where('invoice_id', $id)->update([
                'status_id' => $request->status_id,
                // 'invoice_number' => $request->invoice_number,
                'invoice_category' => $request->invoice_category,
                'invoice_amount' => $request->invoice_amount,
                'invoice_month' => $request->invoice_month,
                'invoice_ppn' => $amountPpn,
                'invoice_payment_timelimit' => $request->invoice_payment_timelimit
            ]);

            return redirect('tenant-invoice')->with('success', 'Invoice baru berhasil dibuat.');
        } catch (\Throwable $th) {
            return redirect()->back()
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }
}
