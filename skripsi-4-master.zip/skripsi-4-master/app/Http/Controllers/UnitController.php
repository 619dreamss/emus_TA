<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Helpers\FunctionsHelper;
use App\Unit;
use Validator;
use DB;

class UnitController extends Controller
{
    protected $role;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index(Request $request)
    {
        $dataRedis = FunctionsHelper::dataRedis();
        $this->isRole = $isRole = FunctionsHelper::checkRole('unit');
        $menuId = $this->isRole['menu_id'];
        $unit = Unit::select(['tenant_id', 'unit_id', 'unit_name', 'unit_number', 'unit_address']);
        if (isset($request->tenant_id)) {
            $unit->where('tenant_id', $request->tenant_id);
        }
        $units = $unit->get();

        return view('unit.index', compact('units', 'menuId'));
    }

    public function create()
    {
        return view('unit.create');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'unit_name' => 'required',
            'unit_number' => 'required|unique:unit',
            'unit_address' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        DB::beginTransaction();
        try {

            $unit = new Unit();
            $unit->unit_name = $request->unit_name;
            $unit->unit_number = $request->unit_number;
            $unit->unit_address = $request->unit_address;
            $unit->save();

            DB::commit();
            return redirect('tenant-unit')->with('success', 'Data unit berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->with('error', $th->getMessage())
                ->withInput();
        }
    }

    public function edit($id)
    {
        $unit = Unit::where('unit_id', $id)->first();
        return view('unit.edit', compact('unit'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'unit_name' => 'required',
            'unit_number' => 'required',
            'unit_address' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        DB::beginTransaction();
        try {

            Unit::where('unit_id', $id)->update([
                'unit_name' => $request->unit_name,
                'unit_number' => $request->unit_number,
                'unit_address' => $request->unit_address,
            ]);

            DB::commit();
            return redirect('tenant-unit')->with('success', 'Data unit berhasil diupdate.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()
                ->with('error', $th->getMessage())
                ->withInput();
        }
    }

    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            Unit::where('unit_id', $id)->destroy();

            DB::commit();
            return redirect()->back()->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->with('error', $th->getMessage());
        }
    }
}
