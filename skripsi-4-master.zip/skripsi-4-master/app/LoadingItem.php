<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoadingItem extends Model
{
    protected $table = 'loading_item';
    protected $primaryKey = 'loading_item_id';

    public function tenant()
    {
        return $this->hasOne('App\Tenant', 'tenant_id', 'tenant_id');
    }

    public function unit()
    {
        return $this->hasOne('App\Unit', 'unit_id', 'unit_id');
    }

    public function status()
    {
        return $this->hasOne('App\Status', 'status_id', 'status_id');
    }
}
