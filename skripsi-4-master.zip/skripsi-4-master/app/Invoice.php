<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $table = 'invoice';

    protected $primaryKey = 'invoice_id';

    public function tenant()
    {
        return $this->belongsTo('App\Tenant', 'tenant_id', 'tenant_id');
    }

    public function status()
    {
        return $this->hasOne('App\Status', 'status_id', 'status_id');
    }

    public function unit()
    {
        return $this->hasOne('App\Unit', 'unit_id', 'unit_id');
    }
}
