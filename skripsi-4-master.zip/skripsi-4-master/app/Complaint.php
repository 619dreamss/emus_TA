<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Complaint extends Model
{
    protected $table = 'complaint';
    protected $primaryKey = 'complaint_id';

    public function tenant()
    {
        return $this->hasOne('App\Tenant', 'tenant_id', 'tenant_id');
    }

    public function unit()
    {
        return $this->hasOne('App\Unit', 'unit_id', 'unit_id');
    }

    public function status()
    {
        return $this->hasOne('App\Status', 'status_id', 'status_id');
    }
}
