<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoleMenu extends Model
{
    protected $table = "roles_menu";

    public function menu()
    {
        return $this->hasOne('App\Menu', 'menu_id', 'menu_id');
    }
}
