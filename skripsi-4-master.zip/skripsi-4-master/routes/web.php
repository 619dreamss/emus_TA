<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Auth\LoginController@index');
Route::get('login', 'Auth\LoginController@login')->name('login');
Route::post('doLogin', 'Auth\LoginController@doLogin')->name('doLogin');
Route::get('logout', 'Auth\LoginController@logout')->name('logout');
Route::get('register', 'Auth\LoginController@register');
Route::get('do-register', 'Auth\LoginController@doRegister')->name('doRegister');
Route::get('home', 'HomeController@index');
Route::get('events', 'HomeController@event');

// USER
Route::get('user/edit/{id}', 'UserController@edit');
Route::get('user/delete/{id}', 'UserController@destroy');
Route::get('user', 'UserController@index')->name('user');
Route::get('user/add', 'UserController@create');
Route::get('user/profile', 'UserController@profile');
Route::post('user/updateProfile', 'UserController@updateProfile')->name('updateProfile');
Route::resource('user', 'UserController');

Route::get('tenant/invoice/{id}', 'TenantController@invoice');
Route::get('tenant/edit/{id}', 'TenantController@edit');
Route::get('tenant/delete/{id}', 'TenantController@destroy');
Route::get('tenant', 'TenantController@index')->name('tenant');
Route::get('tenant/add', 'TenantController@create');
Route::get('tenant/add/unit/{id}', 'TenantController@createUnit');
Route::post('storeUnit', 'TenantController@storeUnit')->name('storeUnit');
Route::resource('tenant', 'TenantController');

Route::get('tenant-invoice', 'InvoiceController@index')->name('tenant-invoice');
Route::get('tenant-invoice/detail/{id}/{unit_id}', 'InvoiceController@detail');
Route::get('tenant-invoice/edit/{id}', 'InvoiceController@edit');
Route::resource('tenant-invoice', 'InvoiceController');

Route::get('tenant-complaint/create', 'ComplaintController@create');
Route::get('tenant-complaint/edit/{id}', 'ComplaintController@edit');
Route::get('tenant-complaint/detail/{id}', 'ComplaintController@detail');
Route::get('tenant-complaint/delete/{id}', 'ComplaintController@delete');
Route::resource('tenant-complaint', 'ComplaintController');

Route::get('tenant-renovation/create', 'RenovationController@create');
Route::get('tenant-renovation/edit/{id}', 'RenovationController@edit');
Route::get('tenant-renovation/detail/{id}', 'RenovationController@detail');
Route::get('tenant-renovation/delete/{id}', 'RenovationController@delete');
Route::resource('tenant-renovation', 'RenovationController');

Route::get('tenant-unit/create', 'UnitController@create');
Route::get('tenant-unit/edit/{id}', 'UnitController@edit');
Route::get('tenant-unit/delete/{id}', 'UnitController@delete');
Route::resource('tenant-unit', 'UnitController');

Route::get('tenant-ikmb/create', 'LoadingItemController@create');
Route::get('tenant-ikmb/edit/{id}', 'LoadingItemController@edit');
Route::get('tenant-ikmb/detail/{id}', 'LoadingItemController@detail');
Route::get('tenant-ikmb/delete/{id}', 'LoadingItemController@delete');
Route::resource('tenant-ikmb', 'LoadingItemController');
